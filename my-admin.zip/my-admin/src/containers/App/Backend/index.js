import Layout from './Layouts';

export default Layout;
