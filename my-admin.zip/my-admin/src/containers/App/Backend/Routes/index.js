import adminRoutes from './routes';
import navigation from './_nav';

export { adminRoutes, navigation };
