import React, { Component } from 'react';

export default class Home extends Component {
  render() {
    return (
      <div>
        <h1> Dashboard Layouts. </h1>
      </div>
    );
  }
}
