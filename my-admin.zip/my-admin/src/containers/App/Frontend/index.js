import ClientLayout from './ClientLayout';

export default ClientLayout;
