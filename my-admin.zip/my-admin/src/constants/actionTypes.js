export const ASYNC_START = 'ASYNC_START';
export const ASYNC_END = 'ASYNC_END';
export const APP_LOAD = 'APP_LOAD';
export const REDIRECT = 'REDIRECT';
export const PROGRESSEVENT = 'PROGRESSEVENT';
